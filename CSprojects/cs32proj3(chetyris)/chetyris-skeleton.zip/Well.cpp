#include "Well.h"
#include "UserInterface.h"

void Well::display(Screen& screen, int x, int y)
{
}
