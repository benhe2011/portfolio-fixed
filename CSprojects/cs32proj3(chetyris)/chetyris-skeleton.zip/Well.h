#ifndef WELL_INCLUDED
#define WELL_INCLUDED

class Screen;

class Well
{
  public:
    void display(Screen& screen, int x, int y);
};

#endif // WELL_INCLUDED
